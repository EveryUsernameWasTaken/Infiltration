﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    public class EnemyHealthBar
    {
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        int health;

        Rectangle border;
        Rectangle healthBar;

        Texture2D tex = Game1.baseTexture;

        int maxHealth;

        public EnemyHealthBar(int health)
        {
            border = new Rectangle(0, 0, 44, 13);
            healthBar = new Rectangle(0, 0, 38, 9);
            this.health = health;
            maxHealth = health;
        }

        virtual public void Update(Rectangle enemyRect)
        {
            healthBar.Width = health * 38 / maxHealth;
            border.X = enemyRect.Center.X - border.Width / 2;
            border.Y = enemyRect.Y - (border.Height + 3);
            healthBar.X = border.X + 3;
            healthBar.Y = border.Y + 2;
        }

        virtual public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, border, Color.Black);
            spriteBatch.Draw(tex, healthBar, Color.Red);
        }
    }
}