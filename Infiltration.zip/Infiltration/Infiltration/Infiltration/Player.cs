﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Infiltration
{
    public enum PlayerState
    {
        OnGround, Jumping, Dashing, Dead
    };

    class Player
    {
        public PlayerState State
        {
            get { return playerState; }
        }
        PlayerState playerState;

        public Rectangle Rectangle
        {
            get { return playerRect; }
            set { playerRect = value; }
        }
        Rectangle playerRect;

        public Rectangle AttackRectangle
        {
            get { return attackRect; }
        }
        Rectangle attackRect;

        Texture2D spriteSheet;

        Rectangle sourceRect;

        Dictionary<string, Animation> animations = new Dictionary<string, Animation>();
        Animation currentAnim;

        GamePadState gp;
        GamePadState oldgp;

        KeyboardState kb;
        KeyboardState oldkb;

        Level currentLevel;

        Color playerColor;
        Color aliveColor = Color.White;
        Color deadColor = Color.Yellow;
        Color dashingColor = Color.Orange;

        int jumpVel, runVel = 10, dashSpeed = 20, deathTimer, attackTime = 30, attackTimer, xVel, yVel = 1, maxDashes = 1, maxHealth = 200, lives = 5;

        bool isFacingRight = true, isAttacking = false;

        HealthBar healthBar;

        double dashVelX, dashVelY, DVXIncrement, DVYIncrement;
        int remainingDashes;

        public Player(Rectangle rectangle, ContentManager Content)
        {
            playerRect = rectangle;
            jumpVel = 0;
            playerColor = aliveColor;
            healthBar = new HealthBar(maxHealth);
            loadContent(Content);
            attackRect = new Rectangle(-100, -100, (int) (playerRect.Width * 1.5), playerRect.Height / 2);
            attackTimer = attackTime;
        }

        private void loadContent(ContentManager Content)
        {
            spriteSheet = Content.Load<Texture2D>("Player\\747ss");
            loadAnimations();
        }

        private void loadAnimations()
        {
            try
            {
                using (StreamReader reader = new StreamReader("Content\\Player\\747ss.txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        string name = reader.ReadLine();
                        int speed = Convert.ToInt32(reader.ReadLine());
                        int numRects = Convert.ToInt32(reader.ReadLine());
                        Rectangle[] sourceRects = new Rectangle[numRects];
                        for (int i = 0; i < numRects; i++)
                        {
                            string line = reader.ReadLine();
                            string[] parts = line.Split(' ');
                            sourceRects[i] = new Rectangle(Convert.ToInt32(parts[0]), Convert.ToInt32(parts[1]), Convert.ToInt32(parts[2]), Convert.ToInt32(parts[3]));
                        }
                        animations.Add(name, new Animation(sourceRects, speed));
                        reader.ReadLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file cound not be read");
                Console.WriteLine(e.Message);
            }
        }

        public void Update(Level currentLevel)
        {
            this.currentLevel = currentLevel;

            getInput();

            healthBar.Update();
            if (healthBar.Health <= 0)
            {
                playerState = PlayerState.Dead;
                healthBar.Health = maxHealth;
                lives--;
                playerColor = deadColor;
                playerRect.X = (int)currentLevel.DeathPosition.X;
                playerRect.Y = (int)currentLevel.DeathPosition.Y;
            }

            switch (playerState)
            {
                case PlayerState.OnGround:
                    playerColor = aliveColor;
                    remainingDashes = maxDashes;
                    dashVelX = 0;
                    dashVelY = 0;
                    DVXIncrement = 0;
                    DVYIncrement = 0;
                    deathTimer = 350;

                    bool inAir = true;
                    foreach (Tile tile in currentLevel.Tiles)
                    {
                        if (tile is Obstacle)
                        {
                            Obstacle obstacle = (Obstacle)tile;
                            if (new Rectangle(playerRect.X, playerRect.Y + 1, playerRect.Width, playerRect.Height).Intersects(obstacle.Rectangle))
                            {
                                inAir = false;
                            }
                        }
                        if (tile is PlatformTile)
                        {
                            PlatformTile platformTile = (PlatformTile)tile;
                            if (new Rectangle(playerRect.X, playerRect.Y + 1, playerRect.Width, playerRect.Height).Intersects(platformTile.Rectangle))
                            {
                                inAir = false;
                            }
                        }
                    }
                    if (inAir)
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = 1;
                    }

                    break;

                case PlayerState.Jumping:
                    playerColor = aliveColor;
                    dashVelX = 0;
                    dashVelY = 0;
                    DVXIncrement = 0;
                    DVYIncrement = 0;
                    jumpVel++;
                    yVel = jumpVel;

                    break;

                case PlayerState.Dashing:
                    playerColor = dashingColor;
                    dashVelX -= DVXIncrement;
                    dashVelY -= DVYIncrement;

                    if (dashVelX == 0 && dashVelY == 0)
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = 0;
                        yVel = 0;
                    }
                    if (Math.Abs(dashVelX) > 0)
                        xVel = (int)dashVelX;
                    if (Math.Abs(dashVelY) > 0)
                        yVel = (int)dashVelY;

                    break;

                case PlayerState.Dead:
                    deathTimer--;

                    if (deathTimer <= 0)
                    {
                        playerColor = aliveColor;
                        playerState = PlayerState.Jumping;
                        healthBar.Health = maxHealth;
                        jumpVel = 1;
                        yVel = 1;
                    }

                    break;
            }

            handleCollisions();

            playerRect.X += xVel;
            playerRect.Y += yVel;

            setAnim();
            currentAnim.Update();
            sourceRect = currentAnim.getSourceRect();

            if (playerState != PlayerState.OnGround)
            {
                //playerRect.Width = sourceRect.Width;
            }
            else
                playerRect.Width = 25;

            xVel = 0;
            yVel = 0;
        }

        private void getInput()
        {
            gp = GamePad.GetState(PlayerIndex.One);
            kb = Keyboard.GetState();

            if (playerState != PlayerState.Dead && playerState != PlayerState.Dashing && !(isAttacking && playerState == PlayerState.OnGround))
            {
                xVel += (int)(gp.ThumbSticks.Left.X * runVel);

                if (gp.ThumbSticks.Left.X == 0)
                {
                    if (kb.IsKeyDown(Keys.A))
                    {
                        xVel -= runVel;
                    }
                    if (kb.IsKeyDown(Keys.D))
                    {
                        xVel += runVel;
                    }
                }
            }

            if (xVel > 0)
                isFacingRight = true;
            else if (xVel < 0)
                isFacingRight = false;

            switch (playerState)
            {
                case PlayerState.OnGround:
                    if (gp.IsButtonDown(Buttons.A) && !oldgp.IsButtonDown(Buttons.A))
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = -20;
                    }

                    if (kb.IsKeyDown(Keys.W) && !oldkb.IsKeyDown(Keys.W))
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = -20;
                    }

                    doDash();
                    doAttack();
                    break;

                case PlayerState.Jumping:
                    doDash();
                    doAttack();
                    break;
            }
            oldgp = gp;
            oldkb = kb;
        }

        private void doDash()
        {
            if ((Math.Abs(gp.ThumbSticks.Left.X) > 0 || Math.Abs(gp.ThumbSticks.Left.Y) > 0) && gp.IsButtonDown(Buttons.Y) && !oldgp.IsButtonDown(Buttons.Y) && remainingDashes > 0)
            {
                playerState = PlayerState.Dashing;
                remainingDashes--;
                dashVelX = gp.ThumbSticks.Left.X * dashSpeed;
                dashVelY = -gp.ThumbSticks.Left.Y * dashSpeed;
                DVXIncrement = dashVelX / dashSpeed;
                DVYIncrement = dashVelY / dashSpeed;
            }

            else if (kb.IsKeyDown(Keys.Space) && !oldkb.IsKeyDown(Keys.Space) && remainingDashes > 0)
            {
                bool isDashing = false;
                if (kb.IsKeyDown(Keys.A))
                {
                    dashVelX -= dashSpeed;
                    isDashing = true;
                }
                if (kb.IsKeyDown(Keys.D))
                {
                    dashVelX += dashSpeed;
                    isDashing = true;
                }
                if (kb.IsKeyDown(Keys.W))
                {
                    dashVelY -= dashSpeed;
                    isDashing = true;
                }
                if (kb.IsKeyDown(Keys.S))
                {
                    dashVelY += dashSpeed;
                    isDashing = true;
                }
                if (isDashing)
                {
                    playerState = PlayerState.Dashing;
                    remainingDashes--;
                    DVXIncrement = dashVelX / dashSpeed;
                    DVYIncrement = dashVelY / dashSpeed;
                }
            }
        }

        private void doAttack()
        {
            if ((gp.IsButtonDown(Buttons.X) || kb.IsKeyDown(Keys.K)) && !isAttacking)
            {
                isAttacking = true;
            }
            if (isAttacking)
            {
                attackTimer--;
                if (attackTimer <= 0)
                {
                    isAttacking = false;
                    attackTimer = attackTime;
                    attackRect = attackRect = new Rectangle(-100, -100, attackRect.Width, attackRect.Height);
                    return;
                }
                if (isFacingRight)
                {
                    attackRect = new Rectangle(playerRect.Right, playerRect.Center.Y - attackRect.Height / 2, attackRect.Width, attackRect.Height);
                }
                else
                {
                    attackRect = new Rectangle(playerRect.Left - attackRect.Width, playerRect.Center.Y - attackRect.Height / 2, attackRect.Width, attackRect.Height);
                }
            }
        }

        private void handleCollisions()
        {
            handleTileCollisions();
            handleEnemyCollisions();
        }

        private void handleTileCollisions()
        {
            Rectangle nextRectangle = new Rectangle();
            Rectangle previousRectangle = new Rectangle();
            int xOffset = 0;
            int yOffset = 0;
            foreach (Tile tile in currentLevel.Tiles)
            {
                if (tile is Obstacle)
                {
                    Obstacle obstacle = (Obstacle)tile;
                    nextRectangle = new Rectangle(playerRect.X + xVel, playerRect.Y, playerRect.Width, playerRect.Height);
                    if (nextRectangle.Intersects(obstacle.Rectangle))
                    {
                        if (xVel > 0)
                        {
                            xOffset = nextRectangle.Right - obstacle.Rectangle.Left;
                        }
                        else if (xVel < 0)
                        {
                            xOffset = -(obstacle.Rectangle.Right - nextRectangle.Left);
                        }
                    }
                    nextRectangle = new Rectangle(playerRect.X, playerRect.Y + yVel, playerRect.Width, playerRect.Height);
                    if (nextRectangle.Intersects(obstacle.Rectangle))
                    {
                        if (yVel > 0)
                        {
                            yOffset = nextRectangle.Bottom - obstacle.Rectangle.Top;
                            playerState = PlayerState.OnGround;
                        }
                        else if (yVel < 0)
                        {
                            yOffset = -(obstacle.Rectangle.Bottom - nextRectangle.Top);
                        }
                    }
                }
                if (tile is PlatformTile)
                {
                    PlatformTile platformTile = (PlatformTile)tile;
                    previousRectangle = new Rectangle(playerRect.X, playerRect.Y - yVel, playerRect.Width, playerRect.Height);
                    if (playerRect.Intersects(platformTile.Rectangle) && previousRectangle.Bottom < platformTile.Rectangle.Top)
                    {
                        playerRect.Y = platformTile.Rectangle.Top - playerRect.Height;
                        yVel = 0;
                        playerState = PlayerState.OnGround;
                    }
                }
                if (tile is HealingTile)
                {
                    HealingTile healingTile = (HealingTile)tile;
                    if (playerRect.Intersects(healingTile.Rectangle))
                    {
                        healthBar.Health++;
                    }
                }
            }
            xVel -= xOffset;
            yVel -= yOffset;
        }

        private void handleEnemyCollisions()
        {
            foreach (Enemy enemy in currentLevel.Enemies)
            {
                if (playerRect.Intersects(enemy.Rectangle))
                {
                    healthBar.Health--;
                }
            }
        }

        private void setAnim()
        {
            switch (playerState)
            {
                case PlayerState.OnGround:
                    if (!(Math.Abs(xVel) > 0))
                        currentAnim = animations["idle"];
                    else
                        currentAnim = animations["walking"];
                    break;
                case PlayerState.Jumping:
                    currentAnim = animations["jumping"];
                    break;
                case PlayerState.Dashing:
                    currentAnim = animations["dashing"];
                    break;
            }
            if (isAttacking)
                currentAnim = animations["attacking"];
        }

        public void Draw(SpriteBatch spriteBatch, SpriteFont font)
        {
            if (isFacingRight)
                spriteBatch.Draw(spriteSheet, playerRect, sourceRect, playerColor);
            else
                spriteBatch.Draw(spriteSheet, playerRect, sourceRect, playerColor, 0f, Vector2.Zero, SpriteEffects.FlipHorizontally, 1.0f);
            if (playerState == PlayerState.Dead && deathTimer > 60)
            {
                string text = "" + (deathTimer / 60);
                spriteBatch.DrawString(font, text, new Vector2(playerRect.Center.X - font.MeasureString(text).X / 2, playerRect.Center.Y - font.MeasureString(text).Y / 2), Color.Red);
            }
            else if (playerState == PlayerState.Dead && deathTimer <= 60)
            {
                string text = "GO!";
                spriteBatch.DrawString(font, text, new Vector2(playerRect.Center.X - font.MeasureString(text).X / 2, playerRect.Center.Y - font.MeasureString(text).Y / 2), Color.Red);
            }
            healthBar.Draw(spriteBatch, font, lives);
            spriteBatch.Draw(Game1.baseTexture, attackRect, Color.Yellow);
        }
    }
}