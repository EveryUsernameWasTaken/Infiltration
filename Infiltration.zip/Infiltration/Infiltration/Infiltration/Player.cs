﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    public enum PlayerState
    {
        OnGround, Jumping, Dashing, Dead
    };

    class Player
    {
        public PlayerState State
        {
            get { return playerState; }
        }
        PlayerState playerState;

        public Rectangle Rectangle
        {
            get { return playerRect; }
            set { playerRect = value; }
        }
        Rectangle playerRect;

        public Texture2D Texture
        {
            get { return playerTex; }
        }
        Texture2D playerTex;

        GamePadState gp;
        GamePadState oldgp;

        KeyboardState kb;
        KeyboardState oldkb;

        Level currentLevel;

        Color playerColor;
        Color aliveColor = Color.Blue;
        Color deadColor = Color.Yellow;
        Color dashingColor = Color.Orange;

        int jumpVel, runVel = 10, deathTimer, xVel, yVel = 1, maxDashes = 2, maxHealth = 200, lives = 99;

        HealthBar healthBar;

        double dashVelX, dashVelY, DVXIncrement, DVYIncrement;
        int remainingDashes;

        public Player(Rectangle rectangle, Texture2D texture)
        {
            playerRect = rectangle;
            playerTex = texture;
            jumpVel = 0;
            playerColor = aliveColor;
            healthBar = new HealthBar(maxHealth);
        }

        public void Update(Level currentLevel)
        {
            this.currentLevel = currentLevel;

            getInput();

            healthBar.Update();
            if (healthBar.Health <= 0)
            {
                playerState = PlayerState.Dead;
                healthBar.Health = maxHealth;
                lives--;
                playerColor = deadColor;
                playerRect.X = (int)currentLevel.DeathPosition.X;
                playerRect.Y = (int)currentLevel.DeathPosition.Y;
            }

            switch (playerState)
            {
                case PlayerState.OnGround:
                    playerColor = aliveColor;
                    remainingDashes = maxDashes;
                    dashVelX = 0;
                    dashVelY = 0;
                    DVXIncrement = 0;
                    DVYIncrement = 0;
                    deathTimer = 350;

                    bool inAir = true;
                    foreach (Tile tile in currentLevel.Tiles)
                    {
                        if (tile is Obstacle)
                        {
                            Obstacle obstacle = (Obstacle)tile;
                            if (new Rectangle(playerRect.X, playerRect.Y + 1, playerRect.Width, playerRect.Height).Intersects(obstacle.Rectangle))
                            {
                                inAir = false;
                            }
                        }
                        if (tile is PlatformTile)
                        {
                            PlatformTile platformTile = (PlatformTile)tile;
                            if (new Rectangle(playerRect.X, playerRect.Y + 1, playerRect.Width, playerRect.Height).Intersects(platformTile.Rectangle))
                            {
                                inAir = false;
                            }
                        }
                    }
                    if (inAir)
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = 1;
                    }

                    break;

                case PlayerState.Jumping:
                    playerColor = aliveColor;
                    dashVelX = 0;
                    dashVelY = 0;
                    DVXIncrement = 0;
                    DVYIncrement = 0;
                    jumpVel++;
                    yVel = jumpVel;

                    break;

                case PlayerState.Dashing:
                    playerColor = dashingColor;
                    dashVelX -= DVXIncrement;
                    dashVelY -= DVYIncrement;

                    if (dashVelX == 0 && dashVelY == 0)
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = 0;
                        yVel = 0;
                    }
                    if (Math.Abs(dashVelX) > 0)
                        xVel = (int)dashVelX;
                    if (Math.Abs(dashVelY) > 0)
                        yVel = (int)dashVelY;

                    break;

                case PlayerState.Dead:
                    deathTimer--;

                    if (deathTimer <= 0)
                    {
                        playerColor = aliveColor;
                        playerState = PlayerState.Jumping;
                        healthBar.Health = maxHealth;
                        jumpVel = 1;
                        yVel = 1;
                    }

                    break;
            }

            handleCollisions();

            playerRect.X += xVel;
            playerRect.Y += yVel;

            xVel = 0;
            yVel = 0;
        }

        private void getInput()
        {
            gp = GamePad.GetState(PlayerIndex.One);
            kb = Keyboard.GetState();

            if (playerState != PlayerState.Dead && playerState != PlayerState.Dashing)
            {
                xVel += (int)(gp.ThumbSticks.Left.X * runVel);

                if (gp.ThumbSticks.Left.X == 0)
                {
                    if (kb.IsKeyDown(Keys.A))
                    {
                        xVel -= runVel;
                    }
                    if (kb.IsKeyDown(Keys.D))
                    {
                        xVel += runVel;
                    }
                }
            }

            switch (playerState)
            {
                case PlayerState.OnGround:
                    if (gp.IsButtonDown(Buttons.A) && !oldgp.IsButtonDown(Buttons.A))
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = -20;
                    }

                    if (kb.IsKeyDown(Keys.W) && !oldkb.IsKeyDown(Keys.W))
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = -20;
                    }

                    doDash();
                    break;

                case PlayerState.Jumping:
                    doDash();
                    break;
            }
            oldgp = gp;
            oldkb = kb;
        }

        private void doDash()
        {
            if ((Math.Abs(gp.ThumbSticks.Left.X) > 0 || Math.Abs(gp.ThumbSticks.Left.Y) > 0) && gp.IsButtonDown(Buttons.Y) && !oldgp.IsButtonDown(Buttons.Y) && remainingDashes > 0)
            {
                playerState = PlayerState.Dashing;
                remainingDashes--;
                dashVelX = gp.ThumbSticks.Left.X * 25;
                dashVelY = -gp.ThumbSticks.Left.Y * 25;
                DVXIncrement = dashVelX / 25;
                DVYIncrement = dashVelY / 25;
            }

            else if (kb.IsKeyDown(Keys.Space) && !oldkb.IsKeyDown(Keys.Space) && remainingDashes > 0)
            {
                bool isDashing = false;
                if (kb.IsKeyDown(Keys.A))
                {
                    dashVelX -= 25;
                    isDashing = true;
                }
                if (kb.IsKeyDown(Keys.D))
                {
                    dashVelX += 25;
                    isDashing = true;
                }
                if (kb.IsKeyDown(Keys.W))
                {
                    dashVelY -= 25;
                    isDashing = true;
                }
                if (kb.IsKeyDown(Keys.S))
                {
                    dashVelY += 25;
                    isDashing = true;
                }
                if (isDashing)
                {
                    playerState = PlayerState.Dashing;
                    remainingDashes--;
                    DVXIncrement = dashVelX / 25;
                    DVYIncrement = dashVelY / 25;
                }
            }
        }

        private void handleCollisions()
        {
            handleTileCollisions();
            handleEnemyCollisions();
        }

        private void handleTileCollisions()
        {
            Rectangle nextRectangle = new Rectangle();
            int xOffset = 0;
            int yOffset = 0;
            foreach (Tile tile in currentLevel.Tiles)
            {
                if (tile is Obstacle)
                {
                    Obstacle obstacle = (Obstacle)tile;
                    nextRectangle = new Rectangle(playerRect.X + xVel, playerRect.Y, playerRect.Width, playerRect.Height);
                    if (nextRectangle.Intersects(obstacle.Rectangle))
                    {
                        if (xVel > 0)
                        {
                            xOffset = nextRectangle.Right - obstacle.Rectangle.Left;
                        }
                        else if (xVel < 0)
                        {
                            xOffset = -(obstacle.Rectangle.Right - nextRectangle.Left);
                        }
                    }
                    nextRectangle = new Rectangle(playerRect.X, playerRect.Y + yVel, playerRect.Width, playerRect.Height);
                    if (nextRectangle.Intersects(obstacle.Rectangle))
                    {
                        if (yVel > 0)
                        {
                            yOffset = nextRectangle.Bottom - obstacle.Rectangle.Top;
                            playerState = PlayerState.OnGround;
                        }
                        else if (yVel < 0)
                        {
                            yOffset = -(obstacle.Rectangle.Bottom - nextRectangle.Top);
                        }
                    }
                }
                if (tile is PlatformTile)
                {
                    PlatformTile platformTile = (PlatformTile)tile;
                    nextRectangle = new Rectangle(playerRect.X, playerRect.Y + yVel, playerRect.Width, playerRect.Height);
                    if (nextRectangle.Intersects(platformTile.Rectangle) && playerRect.Bottom < platformTile.Rectangle.Top)
                    {
                        yOffset = nextRectangle.Bottom - platformTile.Rectangle.Top;
                        playerState = PlayerState.OnGround;
                    }
                }
                if (tile is HealingTile)
                {
                    HealingTile healingTile = (HealingTile)tile;
                    if (playerRect.Intersects(healingTile.Rectangle))
                    {
                        healthBar.Health++;
                    }
                }
            }
            xVel -= xOffset;
            yVel -= yOffset;
        }

        private void handleEnemyCollisions()
        {
            foreach (Enemy enemy in currentLevel.Enemies)
            {
                if (playerRect.Intersects(enemy.Rectangle))
                {
                    healthBar.Health--;
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch, SpriteFont font)
        {
            spriteBatch.Draw(playerTex, playerRect, playerColor);
            if (playerState == PlayerState.Dead && deathTimer > 60)
            {
                string text = "" + (deathTimer / 60);
                spriteBatch.DrawString(font, text, new Vector2(playerRect.Center.X - font.MeasureString(text).X / 2, playerRect.Center.Y - font.MeasureString(text).Y / 2), Color.Red);
            }
            else if (playerState == PlayerState.Dead && deathTimer <= 60)
            {
                string text = "GO!";
                spriteBatch.DrawString(font, text, new Vector2(playerRect.Center.X - font.MeasureString(text).X / 2, playerRect.Center.Y - font.MeasureString(text).Y / 2), Color.Red);
            }
            healthBar.Draw(spriteBatch, font, lives);
        }
    }
}