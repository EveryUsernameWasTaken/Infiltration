﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    public enum PlayerState
    {
        OnGround, Jumping, Dashing, Dead
    };

    class Player
    {
        public PlayerState State
        {
            get { return playerState; }
        }
        PlayerState playerState;

        public Rectangle Rectangle
        {
            get { return playerRect; }
            set { playerRect = value; }
        }
        Rectangle playerRect;

        public Texture2D Texture
        {
            get { return playerTex; }
        }
        Texture2D playerTex;

        KeyboardState kb;
        GamePadState gp;

        Color playerColor;
        Color aliveColor = Color.Blue;
        Color deadColor = Color.Yellow;
        Color dashingColor = Color.Orange;

        int jumpVel, runVel, deathTimer;

        double dashVelX, dashVelY, DVXIncrement, DVYIncrement;
        int remainingDashes;

        public Player(Rectangle rectangle, Texture2D texture)
        {
            playerRect = rectangle;
            playerTex = texture;
            jumpVel = -20;
            runVel = 10;
            playerColor = aliveColor;
        }

        public void Update(Level currentLevel)
        {
            kb = Keyboard.GetState();
            gp = GamePad.GetState(PlayerIndex.One);

            if (playerState != PlayerState.Dead && playerState != PlayerState.Dashing)
            {
                playerRect.X += (int)(gp.ThumbSticks.Left.X * runVel);
            }
            
            handleIntersections(currentLevel);
            switch (playerState)
            {
                case PlayerState.OnGround:
                    playerColor = aliveColor;
                    remainingDashes = 2;
                    deathTimer = 350;

                    if (playerRect.Intersects(currentLevel.Floor))
                    {
                        playerRect.Y -= (playerRect.Bottom - currentLevel.Floor.Top);
                    }
                    else
                    {
                        bool inAir = true;
                        foreach (Tile tile in currentLevel.Tiles)
                        {
                            if (tile is Obstacle)
                            {
                                Obstacle obstacle = (Obstacle)tile;
                                if (playerRect.Bottom == currentLevel.Floor.Top || (playerRect.Intersects(obstacle.Rectangle) && !(playerRect.Right < obstacle.Rectangle.Left || playerRect.Left > obstacle.Rectangle.Right)))
                                {
                                    inAir = false;
                                }
                            }
                        }
                        if (inAir)
                        {
                            playerState = PlayerState.Jumping;
                            jumpVel = 5;
                        }
                    }
                    if (gp.IsButtonDown(Buttons.A))
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = -20;
                    }

                    break;

                case PlayerState.Jumping:
                    playerColor = aliveColor;
                    jumpVel++;
                    playerRect.Y += jumpVel;

                    if (playerRect.Bottom >= currentLevel.Floor.Top)
                        playerState = PlayerState.OnGround;
                    foreach (Tile tile in currentLevel.Tiles)
                    {
                        if (tile is Obstacle)
                        {
                            Obstacle obstacle = (Obstacle)tile;
                            if (playerRect.Intersects(obstacle.Rectangle))
                            {
                                if (playerRect.Bottom >= obstacle.Rectangle.Top && playerRect.Right > obstacle.Rectangle.Left && playerRect.Left < obstacle.Rectangle.Right && playerRect.Top < obstacle.Rectangle.Top)
                                {
                                    playerRect.Y -= (playerRect.Bottom - obstacle.Rectangle.Top);
                                    playerState = PlayerState.OnGround;
                                }
                            }
                        }
                    }

                    if ((Math.Abs(gp.ThumbSticks.Left.X) > 0 || Math.Abs(gp.ThumbSticks.Left.Y) > 0) && gp.IsButtonDown(Buttons.X) && remainingDashes > 0)
                    {
                        playerState = PlayerState.Dashing;
                        remainingDashes--;
                        dashVelX = gp.ThumbSticks.Left.X * 25;
                        dashVelY = -gp.ThumbSticks.Left.Y * 25;
                        DVXIncrement = dashVelX / 25;
                        DVYIncrement = dashVelY / 25;
                    }

                    break;

                case PlayerState.Dashing:
                    playerColor = dashingColor;
                    dashVelX -= DVXIncrement;
                    dashVelY -= DVYIncrement;
                    if (dashVelX == 0 && dashVelY == 0)
                    {
                        playerState = PlayerState.Jumping;
                        jumpVel = 0;
                    }
                    if (Math.Abs(dashVelX) > 0)
                        playerRect.X += (int)dashVelX;
                    if (Math.Abs(dashVelY) > 0)
                        playerRect.Y += (int)dashVelY;
                    

                    if (playerRect.Bottom > currentLevel.Floor.Top)
                    {
                        playerRect.Y -= (playerRect.Bottom - currentLevel.Floor.Top);
                    }

                    foreach (Tile tile in currentLevel.Tiles)
                    {
                        if (tile is Obstacle)
                        {
                            Obstacle obstacle = (Obstacle)tile;
                            if (playerRect.Intersects(obstacle.Rectangle))
                            {
                                if (playerRect.Bottom > obstacle.Rectangle.Top)
                                {
                                    playerRect.Y -= (playerRect.Bottom - obstacle.Rectangle.Top);
                                    playerState = PlayerState.OnGround;
                                    break;
                                }
                                if (playerRect.Right > obstacle.Rectangle.Left)
                                {
                                    playerRect.X -= (playerRect.Right - obstacle.Rectangle.Left);
                                }
                                if (playerRect.Left < obstacle.Rectangle.Right)
                                {
                                    playerRect.X += (obstacle.Rectangle.Right - playerRect.Left);
                                }
                                if (playerRect.Top < obstacle.Rectangle.Bottom)
                                {
                                    playerRect.Y += (obstacle.Rectangle.Bottom - playerRect.Top);
                                }
                            }
                        }
                    }

                    break;

                case PlayerState.Dead:
                    deathTimer--;

                    if (deathTimer <= 0)
                    {
                        playerRect.Y += 15;
                        playerColor = aliveColor;
                    }

                    if (playerRect.Y >= (currentLevel.Floor.Y - 50))
                        playerState = PlayerState.OnGround;

                    break;
            }
        }

        private void handleIntersections(Level currentLevel)
        {
            foreach (Tile tile in currentLevel.Tiles)
            {
                if (tile is Obstacle)
                {
                    Obstacle obstacle = (Obstacle)tile;
                    if (playerRect.Intersects(obstacle.Rectangle) && !(playerRect.Bottom <= obstacle.Rectangle.Top))
                    {
                        if ((kb.IsKeyDown(Keys.Right) || gp.ThumbSticks.Left.X > 0) && playerRect.Right > obstacle.Rectangle.Left)
                        {
                            playerRect.X -= (playerRect.Right - obstacle.Rectangle.Left);
                        }
                        else if ((kb.IsKeyDown(Keys.Left) || gp.ThumbSticks.Left.X < 0) && playerRect.Left < obstacle.Rectangle.Right)
                        {
                            playerRect.X += (obstacle.Rectangle.Right - playerRect.Left);
                        }
                    }
                }
            }
            foreach (Enemy enemy in currentLevel.Enemies)
            {
                if (playerRect.Intersects(enemy.Rectangle))
                {
                    playerState = PlayerState.Dead;
                    playerColor = deadColor;
                    playerRect.X = (int)currentLevel.DeathPosition.X;
                    playerRect.Y = (int)currentLevel.DeathPosition.Y;
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch, SpriteFont font)
        {
            spriteBatch.Draw(playerTex, playerRect, playerColor);
            if (playerState == PlayerState.Dead && deathTimer > 60)
            {
                spriteBatch.DrawString(font, "" + (deathTimer / 60), new Vector2(190, 445), Color.Red);
            }
            else if (playerState == PlayerState.Dead && deathTimer <= 60)
            {
                spriteBatch.DrawString(font, "GO!", new Vector2(180, 445), Color.Red);
            }
        }
    }
}