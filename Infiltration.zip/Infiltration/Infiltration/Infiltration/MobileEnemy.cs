﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class MobileEnemy : Enemy
    {
        int xVel;

        public MobileEnemy(Rectangle rectangle, Texture2D texture) : base (rectangle, texture)
        {
            xVel = 6;
        }

        override public void Update(Level currentLevel)
        {
            foreach (Tile tile in currentLevel.Tiles)
            {
                if (tile is Obstacle)
                {
                    Obstacle obstacle = (Obstacle) tile;
                    if (Rectangle.Intersects(obstacle.Rectangle))
                    {
                        xVel *= -1;
                    }
                }
            }
            Rectangle = new Rectangle(Rectangle.X + xVel, Rectangle.Y, Rectangle.Width, Rectangle.Height);
        }
    }
}