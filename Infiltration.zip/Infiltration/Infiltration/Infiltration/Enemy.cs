﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class Enemy
    {
        public Rectangle Rectangle
        {
            get { return enemyRect; }
            set { enemyRect = value; }
        }
        Rectangle enemyRect;

        public Texture2D Texture
        {
            get { return enemyTex; }
        }
        Texture2D enemyTex;

        public static int health = 100;

        EnemyHealthBar healthBar = new EnemyHealthBar(health);

        bool isBeingAttacked = false;
        int timeSinceAttacked = 181;

        public Enemy(Rectangle rectangle, Texture2D texture)
        {
            enemyRect = rectangle;
            enemyTex = texture;
        }

        virtual public void Update(Level currentLevel, Player player)
        {
            if (handlePlayerCollision(player))
            {
                currentLevel.Enemies.Remove(this);
            }
        }

        public bool handlePlayerCollision(Player player)
        {
            healthBar.Update(enemyRect);
            if (enemyRect.Intersects(player.AttackRectangle))
            {
                healthBar.Health -= 2;
                isBeingAttacked = true;
            }
            else
                isBeingAttacked = false;
            if (isBeingAttacked)
            {
                timeSinceAttacked = 0;
            }
            else
            {
                timeSinceAttacked++;
            }
            return healthBar.Health <= 0;
        }

        virtual public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(enemyTex, enemyRect, Color.Red);
            if (timeSinceAttacked <= 180)
                healthBar.Draw(spriteBatch);
        }
    }
}