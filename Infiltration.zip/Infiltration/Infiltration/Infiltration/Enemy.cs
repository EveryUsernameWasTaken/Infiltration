﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class Enemy
    {
        public Rectangle Rectangle
        {
            get { return enemyRect; }
            set { enemyRect = value; }
        }
        Rectangle enemyRect;

        public Texture2D Texture
        {
            get { return enemyTex; }
        }
        Texture2D enemyTex;

        int xVel;

        public Enemy(Rectangle rectangle, Texture2D texture)
        {
            enemyRect = rectangle;
            enemyTex = texture;
            xVel = 6;
        }

        public void Update(Level currentLevel)
        {
            foreach (Tile tile in currentLevel.Tiles)
            {
                if (tile is Obstacle)
                {
                    Obstacle obstacle = (Obstacle)tile;
                    if (enemyRect.Intersects(obstacle.Rectangle))
                    {
                        xVel *= -1;
                        break;
                    }
                }
            }
            enemyRect.X += xVel;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(enemyTex, enemyRect, Color.Red);
        }
    }
}