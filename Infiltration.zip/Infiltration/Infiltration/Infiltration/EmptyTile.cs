﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
namespace Infiltration
{
    //It's funny because, as the name implies, this class is practically empty

    class EmptyTile : Tile
    {
        public EmptyTile(Rectangle rectangle) : base (rectangle)
        {
        }

        override public void Draw(SpriteBatch spriteBatch)
        {
        }

        public override void Update()
        {
        }
    }
}