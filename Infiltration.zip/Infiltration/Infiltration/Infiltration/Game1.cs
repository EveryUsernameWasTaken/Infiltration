using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;

        Player player;

        List<Level> levels = new List<Level>();
        Level currentLevel;

        GamePadState gp;
        GamePadState oldgp;

        KeyboardState kb;
        KeyboardState oldkb;

        Texture2D baseTexture;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = 1200;
            graphics.PreferredBackBufferHeight = 1000;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
            // TODO: Add your initialization logic here
            oldgp = GamePad.GetState(PlayerIndex.One);
            oldkb = Keyboard.GetState();

            player = new Player(new Rectangle(0, 0, 50, 50), baseTexture);

            List<Enemy> enemies = new List<Enemy>();
            enemies.Add(new Enemy(new Rectangle(700, 840, 60, 60), baseTexture));

            List<Tile> tiles = new List<Tile>();
            tiles.Add(new Obstacle(new Rectangle(400, 800, 100, 100), baseTexture));
            tiles.Add(new Obstacle(new Rectangle(900, 800, 100, 100), baseTexture));

            levels.Add(new Level(player, enemies, tiles, new Rectangle(0, 900, 1200, 100), new Vector2(300, 850), new Vector2(175, 500)));
            currentLevel = levels[0];

            IsMouseVisible = true;
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            baseTexture = Content.Load<Texture2D>("White Square");
            font = Content.Load<SpriteFont>("SpriteFont1");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            kb = Keyboard.GetState();

            if (kb.IsKeyDown(Keys.Escape))
                this.Exit();

            // TODO: Add your update logic here
            player.Update(currentLevel);
            currentLevel.Update();
            oldkb = kb;

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.DarkGray);

            // TODO: Add your drawing code here
            spriteBatch.Begin();

            currentLevel.Draw(spriteBatch);
            player.Draw(spriteBatch, font);

            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}