﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class WindTile : Tile
    {
        public Texture2D Texture
        {
            get { return tex; }
        }
        Texture2D tex;

        public string Direction
        {
            get { return direction; }
        }
        string direction;

        public WindTile(Rectangle rectangle, string direction) : base(rectangle)
        {
            this.direction = direction;
        }

        override public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, this.Rectangle, Color.White);
        }

        public override void Update()
        {
        }
    }
}
