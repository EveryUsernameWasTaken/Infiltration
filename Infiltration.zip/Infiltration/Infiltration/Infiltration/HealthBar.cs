﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
namespace Infiltration
{
    public class HealthBar
    {
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        int health;

        Rectangle border;
        Rectangle healthBar;

        Color barColor = Color.LimeGreen;

        Texture2D tex = Game1.baseTexture;

        int maxHealth;
        int lowHealth;
        int halfHealth;

        public HealthBar(int health)
        {
            border = new Rectangle(18, 17, 210, 28);
            healthBar = new Rectangle(23, 21, 200, 20);
            this.health = health;
            maxHealth = health;
            lowHealth = health / 4;
            halfHealth = health / 2;
        }

        public void Update()
        {
            healthBar.Width = health * 200 / maxHealth;
            if (health < 0)
            {
                health = 0;
            }
            if (health > maxHealth)
            {
                health = maxHealth;
            }
            if (health <= lowHealth)
            {
                barColor = Color.Red;
            }
            else if (health <= halfHealth)
            {
                barColor = Color.Yellow;
            }
            else
            {
                barColor = Color.LimeGreen;
            }
        }

        public void Draw(SpriteBatch spriteBatch, SpriteFont font, int lives)
        {
            spriteBatch.Draw(tex, border, Color.Black);
            spriteBatch.Draw(tex, healthBar, barColor);
            spriteBatch.Draw(tex, new Rectangle(border.Right + 10, border.Y, (int)font.MeasureString("x" + lives).Y + 15, border.Height), Color.Black);
            spriteBatch.DrawString(font, "x" + lives, new Vector2(border.Right + 15, border.Y), Color.White);
        }
    }
}