﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;
namespace Infiltration
{
    class Animation
    {
        Texture2D spriteSheet;
        Rectangle[] sourceRects;
        int timer = 0;
        int speed;
        int currentRect = 0;

        public Animation(string rectangleInfo, int speed)
        {
            ReadFile(rectangleInfo);
            this.speed = speed;
        }

        public Animation(Rectangle[] sourceRects, int speed)
        {
            this.sourceRects = sourceRects;
            this.speed = speed;
        }

        private void ReadFile(string rectangleInfo)
        {
            try
            {
                //Create an instance of Stream REader to read from a file the using statement also closes the Stream reader
                using (StreamReader reader = new StreamReader(rectangleInfo))
                {
                    int numRects = Convert.ToInt32(reader.ReadLine());
                    for (int i = 0; i < numRects; i++)
                    {
                        string line = reader.ReadLine();
                        string[] parts = line.Split(' ');
                        sourceRects[i] = new Rectangle(Convert.ToInt32(parts[0]), Convert.ToInt32(parts[1]), Convert.ToInt32(parts[2]), Convert.ToInt32(parts[3]));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file cound not be read");
                Console.WriteLine(e.Message);
            }
        }

        public void Update()
        {
            timer++;
            if (timer % speed == 0)
            {
                currentRect = (currentRect + 1) % sourceRects.Length;
            }   
        }

        public void Reset()
        {
            timer = 0;
            currentRect = 0;
        }

        public Rectangle getSourceRect()
        {
            return sourceRects[currentRect];
        }
    }
}