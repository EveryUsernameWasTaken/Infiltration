﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Infiltration
{
    class Level
    {
        public List<Enemy> Enemies
        {
            get { return enemies; }
        }
        List<Enemy> enemies=new List<Enemy>();

        public List<Tile> Tiles
        {
            get { return tiles; }
        }
        List<Tile> tiles=new List<Tile>();

        public Vector2 StartPosition
        {
            get { return startPosition; }
        }
        Vector2 startPosition;

        public Vector2 DeathPosition
        {
            get { return deathPosition; }
        }
        Vector2 deathPosition;

        public Level NextLevel
        {
            get { return nextLevel; }
            set { nextLevel = value; }
        }
        Level nextLevel;

        public Level(Player player, string path)
        {
            StreamReader reader=new StreamReader(path);
            loadTiles(reader);
            player.Rectangle = new Rectangle((int)startPosition.X, (int)startPosition.Y, player.Rectangle.Width, player.Rectangle.Height);
        }

        private void loadTiles(StreamReader reader)
        {
            bool initializedDeathPos = false;
            for (int y=0;  !reader.EndOfStream; y++)
            {
                string line = reader.ReadLine();
                char[] tileChars = line.ToCharArray();
                for (int x=0; x<tileChars.Length; x++)
                {
                    switch (tileChars[x])
                    {
                        case '.':
                            tiles.Add(new EmptyTile(new Rectangle(x * Tile.Width, y * Tile.Height, Tile.Width, Tile.Height)));
                            break;
                        case 'o':
                            tiles.Add(new Obstacle(new Rectangle(x * Tile.Width, y * Tile.Height, Tile.Width, Tile.Height)));
                            break;
                        case 'p':
                            tiles.Add(new PlatformTile(new Rectangle(x * Tile.Width, y * Tile.Height, Tile.Width, Tile.Height)));
                            break;
                        case 'h':
                            tiles.Add(new HealingTile(new Rectangle(x * Tile.Width, y * Tile.Height, Tile.Width, Tile.Height)));
                            break;
                        case 'e':
                            enemies.Add(new Enemy(new Rectangle(x * Tile.Width, y * Tile.Height, Tile.Width, Tile.Height), Game1.baseTexture));
                            break;
                        case '+':
                            startPosition = new Vector2(x * Tile.Width, y * Tile.Height);
                            break;
                        case '-':
                            deathPosition = new Vector2(x * Tile.Width, y * Tile.Height);
                            initializedDeathPos = true;
                            break;
                    }
                }
            }
            if (!initializedDeathPos)
                deathPosition = startPosition;
        }

        public void Update()
        {
            foreach (Enemy enemy in enemies)
            {
                enemy.Update(this);
            }
            foreach (Tile tile in tiles)
            {
                tile.Update();
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (Enemy enemy in enemies)
            {
                enemy.Draw(spriteBatch);
            }
            foreach (Tile tile in tiles)
            {
                tile.Draw(spriteBatch);
            }
        }
    }
}