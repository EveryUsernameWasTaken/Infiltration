﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class Level
    {
        public List<Enemy> Enemies
        {
            get { return enemies; }
        }
        List<Enemy> enemies;

        public List<Tile> Tiles
        {
            get { return tiles; }
        }
        List<Tile> tiles;

        public Vector2 StartPosition
        {
            get { return startPosition; }
        }
        Vector2 startPosition;

        public Vector2 DeathPosition
        {
            get { return deathPosition; }
        }
        Vector2 deathPosition;

        public Rectangle Floor
        {
            get { return floor; }
        }
        Rectangle floor;

        public Level(string path)
        {

        }

        public Level(Player player, List<Enemy> enemies, List<Tile> tiles, Rectangle floor, Vector2 startPos, Vector2 deathPos)
        {
            this.enemies = enemies;
            this.tiles = tiles;
            this.floor = floor;
            startPosition = startPos;
            deathPosition = deathPos;
            player.Rectangle = new Rectangle((int)startPos.X, (int)startPos.Y, player.Rectangle.Width, player.Rectangle.Height);
        }

        public void Update()
        {
            foreach (Enemy enemy in enemies)
            {
                enemy.Update(this);
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (Enemy enemy in enemies)
            {
                enemy.Draw(spriteBatch);
            }
            foreach (Tile tile in tiles)
            {
                tile.Draw(spriteBatch);
            }
            spriteBatch.Draw(((Obstacle)tiles[0]).Texture, floor, Color.Green);
        }
    }
}