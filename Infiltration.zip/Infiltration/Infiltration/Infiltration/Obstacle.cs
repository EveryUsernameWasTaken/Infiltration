﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class Obstacle : Tile
    {
        public Texture2D Texture
        {
            get { return tex; }
        }
        Texture2D tex;

        public Obstacle(Rectangle rectangle, Texture2D texture) : base(rectangle)
        {
            tex = texture;
        }

        public Obstacle(Rectangle rectangle) : base(rectangle)
        {
            tex = Game1.baseTexture;
        }

        override public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, this.Rectangle, Color.DarkSlateGray);
        }

        public override void Update()
        {
        }
    }
}
