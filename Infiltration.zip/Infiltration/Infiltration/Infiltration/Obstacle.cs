﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class Obstacle : Tile
    {
        public Rectangle Rectangle
        {
            get { return obstRect; }
            set { obstRect = value; }
        }
        Rectangle obstRect;

        public Texture2D Texture
        {
            get { return obstTex; }
        }
        Texture2D obstTex;

        public Obstacle(Rectangle rectangle, Texture2D texture) : base(TileCollision.Impassable)
        {
            obstRect = rectangle;
            obstTex = texture;
        }

        override public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(obstTex, obstRect, Color.LightGreen);
        }
    }
}
