﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    abstract class Tile
    {
        public Rectangle Rectangle
        {
            get { return rectangle; }
        }
        Rectangle rectangle;

        public static int Width = 64;
        public static int Height = 64;
        public static readonly Vector2 Size = new Vector2(Width, Height);

        public Tile(Rectangle rectangle)
        {
            this.rectangle = rectangle;
        }

        abstract public void Draw(SpriteBatch spriteBatch);
        abstract public void Update();
    }
}