﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Infiltration
{
    class HealingTile : Tile
    {
        public Texture2D Texture
        {
            get { return tex; }
        }
        Texture2D tex;

        public HealingTile(Rectangle rectangle, Texture2D texture) : base(rectangle)
        {
            tex = texture;
        }

        public HealingTile(Rectangle rectangle) : base(rectangle)
        {
            tex = Game1.baseTexture;
        }

        override public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, this.Rectangle, Color.LimeGreen);
        }

        public override void Update()
        {
        }
    }
}